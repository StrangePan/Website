# About This Site

This website is intended to be a place for others to get
to know me, for potential employers to see what I am capable
of, and for me to practice and improve my programming skills.
In addition to blog posts and personal information, I hope to
update this site with projects I am working on. My long term
desire for this site is to serve as a personal library for
references, links, code samples, and anything else that I
find intriguing.

Every line of this website has been hand-coded from
scratch, with the exception of third-party font faces,
images, and video players. The reason I have chosen to build
a custom website rather than use a content management
system such as WordPress or Joomla is simple; I want
first-hand experience working with new web technolgoies and
building powerful applications. Technology is my passion, so
I try to grasp every opportunity I can to learn about these
magical machines that we call "computers."

This site is updated whenever I have time or interest to
do so. It is designed to be simple and minimalistic while
presenting information in a clean and logical manner. Please
regard the simplicity of this site to be an exercise in design
and experimentation rather than a sign of laziness.
