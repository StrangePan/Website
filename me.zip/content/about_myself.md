# About Myself

My name is Daniel Andrus. I play video games, write code,
write blog posts, and start fun side projects. Sometimes I even
finish the side projects. I also work as a full-time software
developer on the side.

I grew up in Southern California and earned my high
school degree in 2009. In 2010, I moved from Los Angeles to a
little town called Spearfish, South Dakota. There, I attended
college at Black Hills State University for two years while
outside of classes I became interested in programming. In
2012, I transferred to South Dakota School of Mines and
Technology where I plan to graduate with a bachelor's degree
of computer science in May, 2016.

Today, I am a college senior with only one semester remaining
until I complete my degree. I live in Rapid City, South
Dakota and work for 7400 Circuits, a small circuit board company.
In addition to being present on the typical social networks, I
occasionally produce videos for a YouTube gaming channel and run
a public video game server. More information on my current and
past endeavors can be found on the Portfolio page of my website.
