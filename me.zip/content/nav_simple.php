<nav class="simple">
	<ul>
		<li><a href="<?php echo $relRoot; ?>" title="Home">Home</a></li>
		<li><a href="<?php echo $relRoot; ?>blog" title="Blog">Blog</a></li>
		<li><a href="<?php echo $relRoot; ?>library" title="Library">Library</a></li>
		<li><a href="<?php echo $relRoot; ?>portfolio" title="Portfolio">Portfolio</a></li>
		<li><a href="<?php echo $relRoot; ?>contact" title="Contact">Contact</a></li>
	</ul>
</nav>
