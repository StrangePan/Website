<div class="info widget steam">
	<header>
		<h1>
			<i class="fa fa-steam fa-lg"></i>
			Steam Widget
		</h1>
	</header>
</div>
