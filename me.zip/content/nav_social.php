<nav class="social">
	<ul>
		<li><a href="https://www.twitter.com/deaboy100" title="Twitter"><span class="fa fa-twitter icon"></span>Twitter</a></li>
		<li><a href="https://www.facebook.com/Deaboy100" title="Facebook"><span class="fa fa-facebook icon"></span>Facebook</a></li>
		<li><a href="https://www.github.com/Deaboy" title="Github"><span class="fa fa-github icon"></span>GitHub</a></li>
		<li><a href="https://www.linkedin.com/in/daniel-andrus-259a27a3
" title="LinkedIn"><span class="fa fa-linkedin-square icon"></span>LinkedIn</a></li>
		<li><a href="https://www.youtube.com/Deaboy100" title="YouTube"><span class="fa fa-youtube-play icon"></span>YouTube</a></li>
		<li><a href="http://steamcommunity.com/id/deaboy" title="Steam"><span class="fa fa-steam icon"></span>Steam</a></li>
	</ul>
</nav>
