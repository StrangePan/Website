<nav class="main">
	<ul>
		<li><a href="<?php echo $relRoot; ?>" title="Home">Home</a></li>
		<li><a href="<?php echo $relRoot; ?>?p=resume" title="Resume">Resume</a></li>
		<li><a href="<?php echo $relRoot; ?>?p=projects" title="Projects">Projects</a></li>
		<li><a href="https://twitter.com/deaboy100" title="Twitter">Twitter</a></li>
	</ul>
</nav>
