<!-- Under construction message -->
<article class="construction error front-and-center">
	<header>
		<h1>Coming Soon!</h1>
	</header>
	<section>
		<p>This page is still under construction! Sorry for the inconvenience.
		Please remember that this site is coded entirely by hand by a single
		guy, so some features or pages may not be ready yet.</p>

		<p>Please accept this picture of a cat as an apology.</p>

		<figure>
			<img src="<?php echo $imgRoot; ?>construction-kitty.jpg" />
		</figure>
	</section>
</article>
