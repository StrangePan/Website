<!-- Under construction message -->
<article class="404 error front-and-center">
	<header>
		<h1>404: Where are you going?</h1>
	</header>
	<section>
		<p>Sorry, but the page you're looking for simply isn't here. Maybe
		it's been moved, maybe it's misplaced, or maybe it never existed. Either
		way, you're at a dead end. Sorry!</p>
	</section>
</article>
